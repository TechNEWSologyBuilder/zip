
Novasports.gr addon for Kodi
======================

About
-----
On-demand Videos and TV Shows from novasports.gr

Kodi Addon for http://www.novasports.gr

This addon is not published nor endorsed by novasports.gr

This addon offers content available in Greece


Artwork
---------------------
Artwork sourced from public domains:

[https://el.wikipedia.org/wiki/Novasports#/media/File:%CE%9Dova_Sports.png]()https://el.wikipedia.org/wiki/Novasports#/media/File:%CE%9Dova_Sports.png)


License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html