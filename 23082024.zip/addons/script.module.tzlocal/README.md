script.module.tzlocal
======================

Python tzlocal library packed for Kodi.

See https://github.com/regebro/tzlocal.git

