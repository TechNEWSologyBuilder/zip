 UI Sounds for the Kodi Aeon MQ 6 skin.
