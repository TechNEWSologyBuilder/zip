import xbmc, xbmcgui, webbrowser


def SitesMenu():
    funcs = (site1, site2, site3, site4, site5, site6, site7, site8, site9)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                         TechNEWSology[/COLOR][/B]', 
['[B][COLOR=white]                                  Υποστήριξη GrecoTM Facebook[/COLOR][/B]',
 '[B][COLOR=white]                                    Υποστήριξη GrecoTM Discord[/COLOR][/B]',
 '[B][COLOR=white]                                 TechNEWSology Channel YouTube[/COLOR][/B]',
 '[B][COLOR=white]                                                     Real Debrid[/COLOR][/B]',
 '[B][COLOR=white]                                                          Trakt[/COLOR][/B]',
 '[B][COLOR=white]                                                          IMDb[/COLOR][/B]',
 '[B][COLOR=white]                                                        thetvdb[/COLOR][/B]',
 '[B][COLOR=white]                                           Ιστότοποι Υποτίτλων[/COLOR][/B]',
 '[B][COLOR=white]                                    Δωρεά TechNEWSology Build[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-9]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()


def site1():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.facebook.com/groups/GRecoTM/' ) )
    else: opensite = webbrowser . open('https://www.facebook.com/groups/GRecoTM/')

def site2():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://discord.gg/vhaHrMc' ) )
    else: opensite = webbrowser . open('https://discord.gg/vhaHrMc')

def site3():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.youtube.com/channel/UCmnxLXwsBe6hvNU-QjAA0-g' ) )
    else: opensite = webbrowser . open('https://www.youtube.com/channel/UCmnxLXwsBe6hvNU-QjAA0-g')

def site4():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://real-debrid.com' ) )
    else: opensite = webbrowser . open('https://real-debrid.com')

def site5():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://trakt.tv/auth/signin' ) )
    else: opensite = webbrowser . open('https://trakt.tv/auth/signin')

def site6():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.imdb.com/' ) )
    else: opensite = webbrowser . open('https://www.imdb.com/')

def site7():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://thetvdb.com' ) )
    else: opensite = webbrowser . open('https://thetvdb.com')

def site8():
    if myplatform == 'android': xbmc.executebuiltin('RunScript(special://skin/16x9/SearchSubs.py)')
    else: xbmc.executebuiltin('RunScript(special://skin/16x9/SearchSubs.py)')

def site9():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.paypal.me/TechNEWSology' ) )
    else: opensite = webbrowser . open('https://www.paypal.me/TechNEWSology')

SitesMenu()
