﻿import os, xbmc, xbmcgui

DIALOG         = xbmcgui.Dialog()
choice = 1
choice = xbmcgui.Dialog().yesno('[COLOR orange]TechNEWSology Skins[/COLOR]', 'Αναλόγως τις δυνατότητες της συσκευή σας, επιλέξτε το κατάλληλο κέλυφος.', '[COLOR white]Σε αργές συσκευές προτείνετε το κέλυφος [COLOR lime]TechNEWSology Faster.[/COLOR]',
                                nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Εγκατάσταση Κελύφους[/COLOR]')
if  choice == 1: xbmc.executebuiltin('ActivateWindow(10040,"addons://repository.TechNEWSology.Gkn/category.lookandfeel",return)')

