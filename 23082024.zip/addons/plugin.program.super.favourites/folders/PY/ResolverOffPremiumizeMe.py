﻿import os, xbmc, xbmcgui

DIALOG         = xbmcgui.Dialog()
choice = 1
choice = xbmcgui.Dialog().yesno('TechNEWSology Tools', 'Αν η συνδρομή μας έχει λήξει, [COLOR orange]απενεργοποιούμε[/COLOR] το Resolver έτσι ώστε να μας εμφανίζονται όλοι οι δωρεάν πάροχοι.                                                                                                       Το [COLOR lime]ενεργοποιούμε[/COLOR] ξανά με τον ίδιο τρόπο όταν ανανεώσουμε την συνδρομή μας.',
                                nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR white]Resolver [COLOR lime]ON[COLOR white]/[COLOR orange]OFF[/COLOR]')
if choice == 1: xbmc.executebuiltin('RunPlugin(plugin://plugin.video.placenta/?action=TogglePreMe)')

