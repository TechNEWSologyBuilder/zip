# -*- coding: utf-8 -*-

from providerModules.a4kScrapers import core

__all__ = core.get_all_relative_py_files(__file__)